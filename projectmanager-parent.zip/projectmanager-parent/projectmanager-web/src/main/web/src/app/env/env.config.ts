import { environment } from '../../environments/environment';

export const Config = environment;

