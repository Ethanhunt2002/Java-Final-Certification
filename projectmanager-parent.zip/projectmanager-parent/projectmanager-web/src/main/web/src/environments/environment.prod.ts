export const environment = {
  production: true,
  API:'http://localhost:8099/'
};
